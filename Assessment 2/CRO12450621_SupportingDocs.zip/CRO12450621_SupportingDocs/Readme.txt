# Unity Project & Code
## Ashley Cromack - CRO12450621 - CMP9056M - MComp Research Project


Folder containing the Unity project where the artefact code is.
The 'ResearchProject' folder is the Unity project, if opening the game through Unity.
The game can also be run using the 'Full_Game.exe' file.

! An Xbox 360 Controller is required for gameplay
